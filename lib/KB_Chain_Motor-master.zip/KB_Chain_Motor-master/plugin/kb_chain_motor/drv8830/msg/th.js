Blockly.Msg.DRV8830_SPEED_TITLE = "ความเร็ว KB Motor";
Blockly.Msg.DRV8830_SPEED_TOOLTIP = "ตั้งค่าความเร็ว KB Motor 0 ถึง 100% (ค่าความเร็วติดลบสำหรับถอยหลัง)";
Blockly.Msg.DRV8830_SPEED_HELPURL = "";

Blockly.Msg.MOTOR = "มอเตอร์";
Blockly.Msg.MOTOR_SPEED = "ความเร็ว";
Blockly.Msg.MOTOR_STATE = "สถานะ";
Blockly.Msg.MOTOR_STANDBY = "สแตนบายด์";
Blockly.Msg.MOTOR_REVERSE = "ถอยหลัง";
Blockly.Msg.MOTOR_FORWARD = "เดินหน้า";
Blockly.Msg.MOTOR_BRAKE = "เบรค";
